// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAKaiWXyZ-i1hEPNu2IS9OQSxkowkZl9xg",
  authDomain: "exercise-app-d5337.firebaseapp.com",
  projectId: "exercise-app-d5337",
  storageBucket: "exercise-app-d5337.appspot.com",
  messagingSenderId: "864276512826",
  appId: "1:864276512826:web:31e3dfde9a1eddf3483503"
};

// Initialize Firebase
initializeApp(firebaseConfig);